import sys
import sqlite3
import numpy as np

from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


# =========================
# DATABASE
# =========================
def init_db():
    conn = sqlite3.connect("life_sim.db")
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS simulations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hours REAL,
        consistency REAL,
        probability REAL
    )
    """)

    conn.commit()
    conn.close()


def save_sim(hours, consistency, prob):
    conn = sqlite3.connect("life_sim.db")
    c = conn.cursor()
    c.execute("INSERT INTO simulations (hours, consistency, probability) VALUES (?, ?, ?)",
              (hours, consistency, prob))
    conn.commit()
    conn.close()


def get_history():
    conn = sqlite3.connect("life_sim.db")
    c = conn.cursor()
    c.execute("SELECT hours, consistency, probability FROM simulations ORDER BY id DESC")
    data = c.fetchall()
    conn.close()
    return data


# =========================
# AI MODEL (simple logic)
# =========================
def ai_predict(hours, consistency):
    score = hours * 12 + consistency * 60
    if score > 80:
        return "🔥 High Success Probability"
    elif score > 50:
        return "⚖️ Moderate Success Probability"
    return "⚠️ Low Success Probability"


# =========================
# MATPLOTLIB CANVAS
# =========================
class Canvas(FigureCanvas):
    def __init__(self):
        self.fig = Figure()
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)


# =========================
# MAIN APP
# =========================
class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Life Simulator ")
        self.setGeometry(100, 100, 1100, 650)

        self.central = QWidget()
        self.setCentralWidget(self.central)

        main_layout = QHBoxLayout()

        # =========================
        # SIDEBAR
        # =========================
        sidebar = QVBoxLayout()

        title = QLabel("⚡ LIFE SIM ")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:18px; font-weight:bold; color:white;")

        btn_sim = QPushButton("📊 Simulation")
        btn_hist = QPushButton("💾 History")
        btn_ai = QPushButton("🤖 AI Prediction")

        btn_sim.clicked.connect(lambda: self.pages.setCurrentIndex(0))
        btn_hist.clicked.connect(self.load_history)
        btn_ai.clicked.connect(lambda: self.pages.setCurrentIndex(2))

        sidebar.addWidget(title)
        sidebar.addWidget(btn_sim)
        sidebar.addWidget(btn_hist)
        sidebar.addWidget(btn_ai)
        sidebar.addStretch()

        # =========================
        # STACKED PAGES
        # =========================
        self.pages = QStackedWidget()

        self.pages.addWidget(self.sim_page_ui())
        self.pages.addWidget(self.history_page_ui())
        self.pages.addWidget(self.ai_page_ui())

        main_layout.addLayout(sidebar, 1)
        main_layout.addWidget(self.pages, 4)

        self.central.setLayout(main_layout)

        # 🌈 COLORFUL UI STYLE
        self.setStyleSheet("""
        QMainWindow {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                        stop:0 #0f2027,
                                        stop:0.5 #203a43,
                                        stop:1 #2c5364);
        }

        QPushButton {
            background-color: rgba(255,255,255,0.15);
            color: white;
            padding: 12px;
            margin: 6px;
            border-radius: 12px;
            font-weight: bold;
        }

        QPushButton:hover {
            background-color: rgba(255,255,255,0.35);
        }

        QLineEdit {
            background-color: rgba(0,0,0,0.4);
            color: white;
            padding: 10px;
            border-radius: 10px;
        }

        QLabel {
            color: white;
        }
        """)

    # =========================
    # SIM PAGE
    # =========================
    def sim_page_ui(self):
        page = QWidget()
        layout = QVBoxLayout()

        card = QGroupBox("Simulation Panel")
        card_layout = QVBoxLayout()

        self.hours = QLineEdit()
        self.hours.setPlaceholderText("Study hours")

        self.consistency = QLineEdit()
        self.consistency.setPlaceholderText("Consistency (0-1)")

        btn = QPushButton("Run Simulation")
        btn.clicked.connect(self.run_sim)

        self.result = QLabel("Result...")

        self.canvas = Canvas()

        card_layout.addWidget(self.hours)
        card_layout.addWidget(self.consistency)
        card_layout.addWidget(btn)
        card_layout.addWidget(self.result)

        card.setLayout(card_layout)

        layout.addWidget(card)
        layout.addWidget(self.canvas)

        page.setLayout(layout)
        return page

    # =========================
    # HISTORY PAGE
    # =========================
    def history_page_ui(self):
        page = QWidget()
        layout = QVBoxLayout()

        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Hours", "Consistency", "Probability"])

        layout.addWidget(QLabel("History"))
        layout.addWidget(self.table)

        page.setLayout(layout)
        return page

    def load_history(self):
        data = get_history()
        self.table.setRowCount(len(data))

        for i, row in enumerate(data):
            for j, val in enumerate(row):
                self.table.setItem(i, j, QTableWidgetItem(str(val)))

        self.pages.setCurrentIndex(1)

    # =========================
    # AI PAGE
    # =========================
    def ai_page_ui(self):
        page = QWidget()
        layout = QVBoxLayout()

        self.ai_input = QLineEdit()
        self.ai_input.setPlaceholderText("hours,consistency")

        btn = QPushButton("Predict")
        btn.clicked.connect(self.run_ai)

        self.ai_result = QLabel("AI Result")

        layout.addWidget(self.ai_input)
        layout.addWidget(btn)
        layout.addWidget(self.ai_result)

        page.setLayout(layout)
        return page

    def run_ai(self):
        try:
            h, c = self.ai_input.text().split(",")
            self.ai_result.setText(ai_predict(float(h), float(c)))
        except:
            self.ai_result.setText("Invalid input")

    # =========================
    # SIMULATION (ANIMATED)
    # =========================
    def run_sim(self):
        try:
            hours = float(self.hours.text())
            cons = float(self.consistency.text())

            x = np.arange(1, 11)

            self.y_low = (hours * 0.5 * cons) * np.log1p(x) * 10
            self.y_mid = (hours * 1.0 * cons) * np.log1p(x) * 10
            self.y_high = (hours * 1.5 * cons) * np.log1p(x) * 10

            self.step = 0

            self.timer = QTimer()
            self.timer.timeout.connect(self.animate)
            self.timer.start(150)

            prob = min(100, hours * 10 + cons * 50)
            self.result.setText(f"Probability: {prob:.2f}%")

            save_sim(hours, cons, prob)

        except:
            self.result.setText("Enter valid values")

    def animate(self):
        self.step += 1
        if self.step > 10:
            self.timer.stop()
            return

        self.canvas.ax.clear()

        self.canvas.fig.patch.set_facecolor("#0f2027")
        self.canvas.ax.set_facecolor("#1c1c1c")

        self.canvas.ax.plot(self.y_low[:self.step], color="red", label="Low")
        self.canvas.ax.plot(self.y_mid[:self.step], color="orange", label="Mid")
        self.canvas.ax.plot(self.y_high[:self.step], color="lime", label="High")

        self.canvas.ax.legend()
        self.canvas.ax.grid(True, alpha=0.3)

        self.canvas.draw()


# =========================
# RUN
# =========================
if __name__ == "__main__":
    init_db()
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())
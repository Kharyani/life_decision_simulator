import numpy as np

def simulate_life(study_hours, consistency):
    days = 180  # 6 months
    growth = []

    skill = 0

    for day in range(days):
        daily_gain = study_hours * consistency * np.random.uniform(0.8, 1.2)
        skill += daily_gain
        growth.append(skill)

    job_probability = min(100, skill / 10)

    return growth, job_probability

if __name__ == "__main__":
    growth, prob = simulate_life(3, 0.8)
    print("Sample Growth:", growth[:5])  # first 5 values
    print("Job Probability:", prob)